# 🔐 Crypt – Assembly Language Encryption & Decryption

This project is a simple **encryption and decryption system** written in **x86 Assembly language (EMU8086)**.  
It demonstrates how substitution-based ciphers can be implemented using **lookup tables** and low-level string manipulation.

---

## ✨ Features
- Accepts a user-input string.  
- **Encrypts** the message using a substitution table.  
- **Decrypts** the message back to the original text.  
- Supports lowercase letters (`a-z`) and spaces.  
- Implements string parsing, character substitution, and DOS interrupts.

---

## ⚙️ How It Works
1. User enters a plain text message.  
2. The program maps each character through **Table 1** for encryption.  
3. The encrypted text is displayed.  
4. The program then uses **Table 2** to reverse the mapping (decryption).  
5. The decrypted message matches the original input.  

---

## 🛠️ Technologies Used
- **EMU8086** assembler & simulator  
- **x86 Assembly language (16-bit)**  
- DOS interrupts for I/O  

---

## 📂 File Structure
- `crypt.asm` → Main assembly source code  

---

## 🚀 Usage
1. Open the project in **EMU8086**.  
2. Assemble and run `crypt.asm`.  
3. Enter a message when prompted.  
4. View the **encrypted** and **decrypted** outputs.  

---

## 💡 Example
Enter the message: hello
Encrypted message: xyzab
Decrypted message: hello



---

## 📖 Learning Outcome
This project helped me understand:  
- How encryption/decryption logic works at a low level.  
- String handling in Assembly language.  
- Practical use of **lookup tables** and **xlat** instruction.  

---

✨ *"Simplicity is the soul of efficiency."* – Austin Freeman
