📦 Pharmacy Management System (C++ OOP Project)
📖 Overview

The Pharmacy Management System is a console-based application written in C++ using Object-Oriented Programming (OOP) principles.
It allows Admins to manage medicines (add, update, delete, search) and Customers to view and search medicines.
All records are stored in a text file (pharmacy_records.txt) for persistence.

⚙️ Features
🔑 Admin

➕ Add new medicines with details (ID, Name, Quantity, Price)

📄 View all medicines

🔍 Search for a medicine by ID

✏️ Update medicine details

❌ Delete medicines


👥 Customer

📄 View available medicines

🔍 Search for a medicine by ID


🛠️ Concepts & Technologies Used

C++

OOP Principles:

Classes & Objects

Inheritance (Base User → Derived Admin, Customer)

Virtual Functions (Polymorphism)

Encapsulation

File Handling (read/write/update/delete using .txt file)

🗂️ File Structure
📦 Pharmacy-Management-System
 ┣ 📜 main.cpp               # Source code
 ┣ 📜 pharmacy_records.txt   # Stores medicine data (auto-created)
 ┗ 📜 README.md              # Documentation

▶️ How to Run
1. Compile the Code

Using g++:

g++ main.cpp -o pharmacy

2. Run the Program
./pharmacy

3. Usage

Select Admin or Customer from the main menu.

Admin credentials are not required (basic version).

Medicines are stored in pharmacy_records.txt.



That't it!!
